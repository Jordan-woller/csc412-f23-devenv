#include <stdio.h>

int main() {
   char msg[] = "Holy smokes, you just code in C an used Bash, congratulations! How many new things did you do today?";
   // printf will print the text to the screen in the terminal (CLI)
   printf("%s", msg);
   return 0; // return 1 if something went wrong
}